<?php

/*
 * @copyright   2014 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

?>
<p class="alert alert-info" style="margin:15px 0 0">
    <i class="fa fa-external-link"></i> <a class="alert-link" href="https://mautic.org/docs/en/plugins/dynamics_crm.html" target="_blank"><?php echo $view['translator']->trans('mautic.plugin.dynamics.doc_link'); ?></a>
</p>

## Tag management user interface for Mautic

All issues and pull requests should be made against https://github.com/mautic/mautic.
<?php
/**
 * @copyright   2016 Digital Innaovation Lab. All rights reserved
 * @author      Christian Wittwer
 *
 * @see        http://diginlab.com
 */

namespace MauticPlugin\MauticTagManagerBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticTagManagerBundle extends PluginBundleBase
{
}

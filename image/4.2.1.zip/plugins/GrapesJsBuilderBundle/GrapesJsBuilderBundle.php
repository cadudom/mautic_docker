<?php

declare(strict_types=1);

namespace MauticPlugin\GrapesJsBuilderBundle;

use Mautic\IntegrationsBundle\Bundle\AbstractPluginBundle;

class GrapesJsBuilderBundle extends AbstractPluginBundle
{
}
